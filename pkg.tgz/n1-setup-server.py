#!/usr/bin/env python3
"""
N1 家用旁路由安裝精靈 - N1 端 server
從 0 開始設定 N1 → 安裝 Xray + DDNS + 路由器配置 → 手機 VPN 連結

用法（從 PC 端 SSH 進 N1 後跑）：
  python3 n1-setup-server.py --port 8080

然後 PC 用瀏覽器開：
  http://<N1_IP>:8080

只需要 Python 3 stdlib（不需要 pip3）。
"""
import http.server
import json
import subprocess
import threading
import queue
import urllib.parse
import argparse
import os
import sys
import time
import re
import shutil
from pathlib import Path

# 更新系統：版本號（每次發布更新包時遞增）
WIZARD_VERSION = "1.0.3"
UPDATE_URL_FILE = "/root/.n1-update-url"
# 預設更新來源：用 refs/heads/main 避開 GitHub raw CDN 卡舊版；可被 /root/.n1-update-url 覆蓋
DEFAULT_UPDATE_URL = "https://raw.githubusercontent.com/lmmark369-lgtm/n1-updates/refs/heads/main/manifest.json"

def _get_update_url():
    try:
        v = Path(UPDATE_URL_FILE).read_text().strip()
        if v:
            return v
    except Exception:
        pass
    return DEFAULT_UPDATE_URL

def _version_tuple(v):
    try:
        nums = re.findall(r"\d+", str(v))[:3]
        return tuple(int(x) for x in nums) if nums else (0, 0, 0)
    except Exception:
        return (0, 0, 0)

def _fix_github_url(url):
    """把常見的錯誤 GitHub 網址自動轉成可用的 raw 直連
       blob/main/x → raw/main/x；github.com/.../blob → raw.githubusercontent.com/..."""
    try:
        u = url.strip()
        # github.com/user/repo/blob/BRANCH/FILE → raw.githubusercontent.com/user/repo/BRANCH/FILE
        m = re.match(r"https?://github\.com/([^/]+)/([^/]+)/blob/([^/]+)/(.+)$", u)
        if m:
            fixed = f"https://raw.githubusercontent.com/{m.group(1)}/{m.group(2)}/{m.group(3)}/{m.group(4)}"
            log(f"  自動修正 GitHub 網址: blob → raw")
            return fixed
        # github.com/user/repo/raw/BRANCH/FILE → raw.githubusercontent.com（也可用，保留）
        return u
    except Exception:
        return url

STATE = {
    "status": "idle",  # idle | running | done | error
    "log": [],
    "step": "",
    "result": None,
    "started_at": None,
    "finished_at": None,
    "log_queue": queue.Queue(),
    "log_event": threading.Event(),
}

CONFIG_PATH = "/etc/ddns-go/config.yaml"
XRAY_CONFIG = "/usr/local/etc/xray/config.json"

HTML_PAGE = r'''<!DOCTYPE html>
<html lang="zh-Hant">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>N1 家用旁路由安裝精靈</title>
<style>
:root{--bg:#1a1d23;--bg2:#252932;--bg3:#0e1014;--border:#3a3f4a;--text:#e6e6e6;--text2:#9aa0a6;--green:#5cb85c;--blue:#5bc0de;--orange:#f0ad4e;--red:#d9534f;--accent:#00a8c6}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","Noto Sans TC",sans-serif;background:var(--bg);color:var(--text);font-size:14px;line-height:1.6;padding:0;margin:0}
.container{max-width:900px;margin:0 auto;padding:30px 20px}
header{background:var(--bg3);border-bottom:1px solid var(--border);padding:16px 20px;display:flex;align-items:center;gap:12px;margin-bottom:0}
header h1{font-size:18px;color:var(--accent);font-weight:600;margin:0}
header h1::before{content:"▣";margin-right:8px}
header .right{margin-left:auto;color:var(--text2);font-size:12px}
.card{background:var(--bg2);border:1px solid var(--border);border-radius:6px;padding:20px 22px;margin-bottom:16px}
.card h2{font-size:13px;color:var(--accent);margin-bottom:12px;font-weight:700;text-transform:uppercase;letter-spacing:.8px;display:flex;align-items:center;gap:8px}
.card h2::before{content:"●";color:var(--accent);font-size:8px}
.form-row{margin-bottom:14px}
.form-row label{display:block;margin-bottom:5px;font-size:12px;color:var(--text2);font-weight:500}
.form-row label .req{color:var(--red);margin-left:2px}
.form-row label .hint{color:var(--text2);font-weight:normal;margin-left:6px;font-size:11px}
.form-row input,.form-row select{width:100%;background:var(--bg);color:var(--text);border:1px solid var(--border);border-radius:3px;padding:9px 12px;outline:none}
.form-row input:focus,.form-row select:focus{border-color:var(--accent)}
.form-row .row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.btn{padding:10px 20px;background:var(--bg2);color:var(--text);border:1px solid var(--border);border-radius:3px;cursor:pointer;font-weight:500;font-size:14px}
.btn:hover{background:var(--border)}
.btn:disabled{opacity:.4;cursor:not-allowed}
.btn-primary{background:var(--accent);border-color:var(--accent);color:#fff}
.btn-primary:hover:not(:disabled){background:#0090b0}
.btn-success{background:var(--green);border-color:var(--green);color:#fff}
.btn-success:hover:not(:disabled){background:#4a9d4a}
.btn-danger{background:var(--red);border-color:var(--red);color:#fff}
.btn-lg{padding:14px 32px;font-size:16px;width:100%;margin-top:8px}
.alert{padding:12px 16px;border-radius:3px;margin-bottom:14px;font-size:13px;line-height:1.6;display:flex;gap:10px;align-items:flex-start}
.alert::before{flex-shrink:0;font-size:16px;line-height:1.4}
.alert-info{background:rgba(91,192,222,.1);color:var(--blue);border-left:3px solid var(--blue)}
.alert-info::before{content:"ⓘ"}
.alert-warn{background:rgba(240,173,78,.1);color:var(--orange);border-left:3px solid var(--orange);font-weight:500}
.alert-warn::before{content:"⚠"}
.alert-err{background:rgba(217,83,79,.1);color:var(--red);border-left:3px solid var(--red);font-weight:500}
.alert-err::before{content:"✕"}
.alert-ok{background:rgba(92,184,92,.1);color:var(--green);border-left:3px solid var(--green)}
.alert-ok::before{content:"✓"}
.tag{display:inline-block;padding:2px 8px;border-radius:3px;font-size:11px;font-weight:500;margin-right:4px}
.tag-ok{background:rgba(92,184,92,.15);color:var(--green);border:1px solid var(--green)}
.tag-warn{background:rgba(240,173,78,.15);color:var(--orange);border:1px solid var(--orange)}
.tag-err{background:rgba(217,83,79,.15);color:var(--red);border:1px solid var(--red)}
.tag-info{background:rgba(91,192,222,.15);color:var(--blue);border:1px solid var(--blue)}
pre{background:var(--bg3);border:1px solid var(--border);border-radius:3px;padding:14px;font-family:Menlo,Consolas,monospace;font-size:12px;overflow-x:auto;line-height:1.6;color:#d0d0d0;margin:8px 0;white-space:pre-wrap;word-break:break-all}
.terminal{background:#000;border:1px solid var(--border);border-radius:3px;padding:12px;font-family:Menlo,Consolas,monospace;font-size:12px;color:#0f0;min-height:200px;max-height:400px;overflow-y:auto;white-space:pre-wrap;line-height:1.5}
.terminal .err{color:#f55}
.terminal .warn{color:#fa3}
.terminal .info{color:#5cf}
.terminal .ok{color:#5cb85c;font-weight:600}
.progress{height:6px;background:var(--border);border-radius:3px;overflow:hidden;margin:8px 0 16px}
.progress-bar{height:100%;background:linear-gradient(90deg,var(--accent),var(--blue));width:0%;transition:width .5s}
.step{padding:10px 14px;border-radius:3px;margin:4px 0;background:var(--bg);border:1px solid var(--border);font-size:13px;display:flex;align-items:center;gap:8px}
.step.done{background:rgba(92,184,92,.1);border-color:var(--green);color:var(--green)}
.step.doing{background:rgba(91,192,222,.1);border-color:var(--blue);color:var(--blue)}
.step.err{background:rgba(217,83,79,.1);border-color:var(--red);color:var(--red)}
.step::before{content:"○";font-size:14px;font-weight:700;color:var(--text2)}
.step.done::before{content:"✓";color:var(--green)}
.step.doing::before{content:"⟳";color:var(--blue);animation:spin 1s linear infinite}
.step.err::before{content:"✕";color:var(--red)}
@keyframes spin{from{transform:rotate(0)}to{transform:rotate(360deg)}}
</style>
</head>
<body>
<header>
  <h1>N1 家用旁路由安裝精靈</h1>
  <div class="right" style="display:flex;align-items:center;gap:14px;flex-wrap:wrap;justify-content:flex-end">
    <a href="/manual" target="_blank" style="color:var(--text2);font-size:13px;text-decoration:none">📖 手冊</a>
    <a href="javascript:void(0)" onclick="toggleAdmin()" style="color:var(--text2);font-size:13px;text-decoration:none">⚙️ 管理</a>
    <span id="status-pill">就緒</span>
  </div>
</header>
<div class="container">

<div id="step-form" class="card">
  <h2>填寫資料</h2>
  <div class="alert alert-info">
    <div>把資料填好，按下「開始安裝」後，<b>所有指令都會在 N1 上自動跑</b>。整個過程約 2-5 分鐘。</div>
  </div>

  <div class="form-row">
    <div class="row">
      <div>
        <label>DuckDNS Token <span class="req">*</span> <span class="hint">到 duckdns.org 登入取得</span></label>
        <input type="text" id="duckdns-token">
      </div>
      <div>
        <label>DuckDNS 子網域 <span class="req">*</span> <span class="hint">不含 .duckdns.org，需自己申請</span></label>
        <input type="text" id="duckdns-domain">
      </div>
    </div>
  </div>

  <div class="form-row">
    <div class="row">
      <div>
        <label>N1 主機名 <span class="req">*</span></label>
        <input type="text" id="n1-name" value="your-n1-name">
      </div>
      <div>
        <label>N1 對外 port <span class="req">*</span> <span class="hint">路由器要轉發這個 port</span></label>
        <input type="number" id="ext-port" min="1024" max="65535"><span class="hint" id="ext-port-hint">偵測中...</span>
      </div>
    </div>
  </div>

  <div class="form-row">
    <div class="row">
      <div>
        <label>偽裝網站 (SNI) <span class="hint">Reality 偽裝瀏覽哪個網站</span></label>
        <select id="sni">
          <option value="dash.cloudflare.com" selected>Cloudflare (dash.cloudflare.com) · 推薦</option>
          <option value="www.microsoft.com">Microsoft (www.microsoft.com)</option>
          <option value="www.apple.com">Apple (www.apple.com)</option>
          <option value="itunes.apple.com">Apple iTunes (itunes.apple.com)</option>
          <option value="www.bing.com">Bing (www.bing.com)</option>
          <option value="www.samsung.com">Samsung (www.samsung.com)</option>
        </select>
      </div>
    </div>
  </div>

  <div class="form-row">
    <div class="row">
      <div>
        <label>路由器後台網址 <span class="req">*</span></label>
        <input type="text" id="router-url" value="http://192.168.31.1">
      </div>
      <div>
        <label>路由器 admin 密碼 <span class="req">*</span></label>
        <input type="password" id="router-pwd" placeholder="你的小米路由器密碼">
      </div>
    </div>
  </div>

  <div class="form-row">
    <button class="btn btn-primary btn-lg" id="btn-start" onclick="startInstall()">🚀 開始安裝（從 0 到 VPN）</button>
  </div>
</div>

<div id="admin-panel" class="card" style="display:none;margin-top:12px">
  <h2>⚙️ 系統管理</h2>
  <div class="alert alert-info"><div>擁有者可在此直接更改盒子的登入憑證。僅限內網使用（此頁無另外驗證）。</div></div>

  <div class="form-row">
    <div class="row">
      <div>
        <label>Samba 密碼（內網瀏覽檔案，帳號 nas）</label>
        <input type="password" id="adm-samba" placeholder="新密碼（至少4字元）">
      </div>
      <div style="display:flex;align-items:flex-end">
        <button class="btn btn-primary" onclick="admChange('samba')">更改 Samba 密碼</button>
      </div>
    </div>
  </div>

  <div class="form-row">
    <div class="row">
      <div>
        <label>Syncthing GUI 密碼（帳號固定 admin）</label>
        <input type="password" id="adm-syncthing" placeholder="新密碼（至少4字元）">
      </div>
      <div style="display:flex;align-items:flex-end">
        <button class="btn btn-primary" onclick="admChange('syncthing')">更改 Syncthing 密碼</button>
      </div>
    </div>
  </div>

  <div class="form-row">
    <div class="row">
      <div>
        <label>主機名（影響 mDNS 訪問位址）</label>
        <input type="text" id="adm-hostname" placeholder="如 myhome-n1">
      </div>
      <div style="display:flex;align-items:flex-end">
        <button class="btn btn-primary" onclick="admChange('hostname')">更改主機名</button>
      </div>
    </div>
  </div>

  <div id="adm-msg" style="margin-top:8px;font-size:14px;color:var(--text2)"></div>

  <h2 style="margin-top:22px">🔄 系統更新</h2>
  <div class="alert alert-info"><div>從賣家提供的更新來源檢查並套用新版程式。</div></div>
  <div class="form-row">
    <div class="row">
      <div>
        <label>更新來源（manifest.json 網址）</label>
        <input type="text" id="upd-url" placeholder="https://你的主機/manifest.json">
      </div>
      <div style="display:flex;align-items:flex-end">
        <button class="btn" onclick="updSaveUrl()">儲存來源</button>
      </div>
    </div>
  </div>
  <div class="form-row">
    <div class="row">
      <div>
        <label>目前版本</label>
        <div id="upd-ver" style="font-size:14px;color:var(--text2)">—</div>
      </div>
      <div style="display:flex;align-items:flex-end;gap:8px">
        <button class="btn" onclick="updCheck()">🔄 檢查更新</button>
        <button class="btn btn-primary" id="upd-apply" onclick="updApply()" style="display:none">⬇️ 下載並套用</button>
      </div>
    </div>
  </div>
  <div id="upd-status" style="margin-top:8px;font-size:14px;color:var(--text2);white-space:pre-wrap"></div>
</div>

<div id="step-running" class="card" style="display:none">
  <h2>安裝進度</h2>
  <div class="progress"><div class="progress-bar" id="progress-bar"></div></div>
  <div id="steps-list"></div>
  <h2 style="margin-top:20px">執行 log</h2>
  <div class="terminal" id="terminal"></div>
</div>

<div id="step-done" class="card" style="display:none">
  <h2>🎉 安裝完成</h2>
  <div class="alert alert-ok">
    <div>N1 VPN 路由已全部設定完成！<b>複製下面 vless 連結到你的手機 VPN App</b>（v2rayNG / Shadowrocket / V2Box），離開家裡用 4G/5G 測試。</div>
  </div>
  <h2>vless 連結：<span style="color:var(--orange)">網域版</span> / <span style="color:var(--c4,#5bc0de)">公網IP版</span></h2>
  <div>每條都可複製到手機 v2rayNG 匯入；跨境不穩時可換 XHTTP 那條。</div>
  <div id="vless-links" style="margin-top:8px"></div>
  <div id="copy-tip" style="font-size:12px;color:var(--text2);margin-top:6px"></div>

  <h2 style="margin-top:24px">接下來要做的事</h2>
  <ol style="margin-left:20px;line-height:2">
    <li><b>設定路由器 port forward</b>（已在 wizard 自動跑）</li>
    <li>手機關 WiFi 用 4G/5G 連 VPN</li>
    <li>瀏覽器到 <code>https://ifconfig.me</code> 應顯示香港 IP</li>
  </ol>

  <h2 style="margin-top:20px">N1 設定摘要</h2>
  <div id="summary" class="card" style="background:var(--bg3)"></div>
</div>

</div>

<script>
// 頁面載入自動偵測：從 N1 查 LAN IP / 閘道 / 公網 / 建議名，預填表單
(async function autoDetect(){
  try {
    const r = await fetch('/api/detect');
    if (!r.ok) return;
    const d = await r.json();
    if (d.gateway) document.getElementById('router-url').value = 'http://' + d.gateway;
    if (d.suggested_name) document.getElementById('n1-name').value = d.suggested_name;
    // 埠號：依 UPnP 偵測結果決定
    const hint = document.getElementById('ext-port-hint');
    if (d.upnp) {
      // 有 UPnP：隨機 5 位高埠（30000~59999），不同盒不撞
      const pMin=30000, pMax=59999;
      document.getElementById('ext-port').value = Math.floor(pMin + Math.random()*(pMax-pMin+1));
      if (hint) hint.textContent = '載入時自動隨機高埠，可改';
    } else {
      // 沒 UPnP：清空埠，請用戶自行輸入
      document.getElementById('ext-port').value = '';
      if (hint) hint.textContent = '偵測沒有 UPnP，請自行輸入';
    }
    // 注意：DuckDNS 子網域 + token 不能自動填 — 必須用戶自己申請自己填
  } catch(e) { /* 偵測失敗就算了 */ }
})();

function toggleAdmin(){
  const p = document.getElementById('admin-panel');
  p.style.display = (p.style.display === 'none') ? 'block' : 'none';
}

async function admChange(kind){
  const msg = document.getElementById('adm-msg');
  msg.style.color = 'var(--text2)';
  msg.textContent = '處理中...';
  let body = {};
  let endpoint = '';
  if (kind === 'samba') {
    body = { password: document.getElementById('adm-samba').value };
    endpoint = '/api/admin/samba';
  } else if (kind === 'syncthing') {
    body = { password: document.getElementById('adm-syncthing').value };
    endpoint = '/api/admin/syncthing';
  } else {
    body = { hostname: document.getElementById('adm-hostname').value.trim() };
    endpoint = '/api/admin/hostname';
  }
  try {
    const r = await fetch(endpoint, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) });
    const d = await r.json();
    if (d.ok) {
      msg.style.color = 'var(--green)';
      msg.textContent = '✓ ' + (d.msg || '成功');
      if (kind === 'samba') document.getElementById('adm-samba').value = '';
      if (kind === 'syncthing') document.getElementById('adm-syncthing').value = '';
    } else {
      msg.style.color = 'var(--red)';
      msg.textContent = '✗ ' + (d.error || '失敗');
    }
  } catch(e) {
    msg.style.color = 'var(--red)';
    msg.textContent = '✗ 連線失敗: ' + e;
  }
}

let _updAvailable = null;

async function updLoadInfo(){
  try {
    const r = await fetch('/api/update/info');
    const d = await r.json();
    document.getElementById('upd-ver').textContent = 'v' + d.version;
    if (d.update_url) document.getElementById('upd-url').value = d.update_url;
  } catch(e) {}
}

async function updSaveUrl(){
  const st = document.getElementById('upd-status');
  st.textContent = '處理中...';
  try {
    const r = await fetch('/api/admin/update-url', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({url: document.getElementById('upd-url').value.trim()}) });
    const d = await r.json();
    st.textContent = d.ok ? '✓ ' + d.msg : '✗ ' + (d.error || '失敗');
  } catch(e) { st.textContent = '✗ ' + e; }
}

async function updCheck(){
  const st = document.getElementById('upd-status');
  const btn = document.getElementById('upd-apply');
  st.textContent = '檢查中...';
  btn.style.display = 'none';
  try {
    const r = await fetch('/api/update/check');
    const d = await r.json();
    if (d.error) { st.textContent = '✗ ' + d.error; return; }
    if (d.available) {
      st.textContent = `🎉 有新版可用！目前 v${d.current} → 最新 v${d.remote}` + (d.notes ? `\n${d.notes}` : '');
      _updAvailable = { url: d.download_url, sha256: d.sha256 || '' };
      btn.style.display = 'inline-block';
    } else {
      st.textContent = `✓ 已是最新版（v${d.current}）`;
      _updAvailable = null;
    }
  } catch(e) { st.textContent = '✗ ' + e; }
}

async function updApply(){
  const st = document.getElementById('upd-status');
  if (!_updAvailable) { st.textContent = '請先檢查更新'; return; }
  if (!confirm('即將下載並套用更新，服務會重啟約 30 秒。繼續？')) return;
  st.textContent = '⬇️ 下載中（依網路可能需 1-2 分鐘）...';
  try {
    const r = await fetch('/api/update/apply', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(_updAvailable) });
    const d = await r.json();
    st.textContent = d.ok ? '✓ ' + d.msg : '✗ ' + (d.error || '失敗');
  } catch(e) { st.textContent = '✗ ' + e; }
}

// 開管理面板時順便載入版本資訊
const _origToggle = toggleAdmin;
toggleAdmin = function(){
  _origToggle();
  const p = document.getElementById('admin-panel');
  if (p.style.display !== 'none') updLoadInfo();
};
const STEPS = [
  {id:'sysinfo',     name:'檢查系統環境',         desc:'查看 N1 系統版本、磁碟、網路'},
  {id:'hostname',    name:'設定 N1 主機名',       desc:'把 hostname 改成你取的名字'},
  {id:'duckdns',     name:'註冊 DuckDNS 子網域',   desc:'呼叫 DuckDNS API 註冊（用現有 token）'},
  {id:'bbr',         name:'啟用 BBR 加速',         desc:'加快 VPN 連線速度'},
  {id:'xray',        name:'安裝 Xray VPN',         desc:'安裝 v26.3.27 + 寫設定檔 + 啟動'},
  {id:'vpn-test',    name:'VPN 通道測試',         desc:'N1 本機 curl ifconfig.me 確認 VPN 通'},
  {id:'ddns-go',     name:'安裝 DDNS-go',         desc:'下載 binary + 設 DuckDNS callback + 啟動'},
  {id:'emmс',        name:'灌 Armbian 到 eMMC',     desc:'讓 N1 開機不需 USB 碟'},
  {id:'router-pf',   name:'設定路由器 port forward', desc:'轉發外部 port 到 N1'},
  {id:'final',       name:'完成 + 產生 vless 連結', desc:'彙整所有設定、輸出 vless:// 連結'},
];

function renderSteps(currStep, status){
  const list = document.getElementById('steps-list');
  list.innerHTML = STEPS.map(s => {
    let cls = '';
    if(status === 'done' || s.id === currStep && status === 'done') cls = 'done';
    else if(s.id === currStep) cls = 'doing';
    else if(currStep && STEPS.findIndex(x => x.id === s.id) < STEPS.findIndex(x => x.id === currStep)) cls = 'done';
    return `<div class="step ${cls}"><span>${s.name}</span></div>`;
  }).join('');
}

async function startInstall(){
  const cfg = {
    duckdns_token: document.getElementById('duckdns-token').value.trim(),
    duckdns_domain: document.getElementById('duckdns-domain').value.trim(),
    n1_name: document.getElementById('n1-name').value.trim(),
    ext_port: parseInt(document.getElementById('ext-port').value),
    router_url: document.getElementById('router-url').value.trim(),
    router_pwd: document.getElementById('router-pwd').value,
    sni: document.getElementById('sni').value,
    mode: 'both',
  };
  // 必填檢查
  const required = ['duckdns_token','duckdns_domain','n1_name','ext_port','router_url','router_pwd'];
  for(const k of required){
    if(!cfg[k] || (k === 'ext_port' && isNaN(cfg[k]))){
      alert('請填所有必填欄位');
      return;
    }
  }
  if(!confirm('即將在 N1 上跑安裝指令，過程約 2-5 分鐘，繼續？')) return;

  document.getElementById('step-form').style.display = 'none';
  document.getElementById('step-running').style.display = 'block';
  document.getElementById('status-pill').textContent = '⏳ 執行中';
  document.getElementById('status-pill').style.color = 'var(--orange)';
  renderSteps(null, 'running');

  try {
    const r = await fetch('/api/install', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify(cfg)
    });
    if(!r.ok) throw new Error('HTTP ' + r.status);
    await pollStatus();
  } catch(e){
    document.getElementById('terminal').innerHTML += '<div class="err">✕ ' + e.message + '</div>';
  }
}

// 4 條 vless 連結顯示 + 複製
window.__VLESS = [];
const _VLESS_LABELS = ['🚀 TCP · 網域版','✈️ XHTTP · 網域版','🚀 TCP · 公網IP版','✈️ XHTTP · 公網IP版'];
function renderLinks(res){
  window.__VLESS = [res.vless_tcp_dns, res.vless_xhttp_dns, res.vless_tcp_ip, res.vless_xhttp_ip];
  const box = document.getElementById('vless-links');
  box.innerHTML = window.__VLESS.map((link, i)=>`<div style="border:1px solid var(--border);border-radius:8px;margin:10px 0;padding:10px">
      <div style="font-size:13px;color:var(--text2);margin-bottom:4px">${_VLESS_LABELS[i]}</div>
      <div style="display:flex;gap:8px;align-items:flex-start">
        <pre style="flex:1;margin:0;background:#0e1014;color:#0f0;border:1px solid var(--green);border-radius:6px;padding:8px;font-size:11px;white-space:pre-wrap;word-break:break-all">${link}</pre>
        <button class="btn" onclick="copyIdx(${i}, this)">複製</button>
      </div>
    </div>`).join('');
}
function copyIdx(i, btn){
  const txt = window.__VLESS[i] || '';
  const tip = document.getElementById('copy-tip');
  const done = () => { btn.textContent='✓ 已複製'; setTimeout(()=>btn.textContent='複製',2000); };
  if (navigator.clipboard && window.isSecureContext) {
    navigator.clipboard.writeText(txt).then(done).catch(()=>{ fallbackCopy(txt, btn, tip); done(); });
  } else {
    fallbackCopy(txt, btn, tip);
    done();
  }
}

// 複製（改用 4 條連結的 copyIdx，相容 Edge http 的 fallback 仍在）
function copyVless(){
  copyIdx(0, document.getElementById('copy-btn') || document.getElementById('copy-tip'));
}

function fallbackCopy(txt, btn, tip){
  // 舊版：建 textarea 選取複製
  const ta = document.createElement('textarea');
  ta.value = txt;
  ta.style.position = 'fixed';
  ta.style.opacity = '0';
  document.body.appendChild(ta);
  ta.select();
  try {
    const ok = document.execCommand('copy');
    if (ok) {
      btn.textContent = '✓ 已複製';
      tip.textContent = '已複製（' + txt.length + ' 字元）';
      setTimeout(() => { btn.textContent = '複製'; }, 2000);
    } else {
      btn.textContent = '複製失敗';
      tip.textContent = '請手動選取 vless 連結（綠框內文字）複製';
    }
  } catch (e) {
    btn.textContent = '複製失敗';
    tip.textContent = '請手動選取 vless 連結（綠框內文字）複製';
  }
  document.body.removeChild(ta);
}

// 頁面載入時檢查 localStorage（之前是否跑過）
(function() {
  try {
    const cached = localStorage.getItem('n1-wizard-done');
    if (cached) {
      const d = JSON.parse(cached);
      // 舊版存的資料可能缺 4 條連結 → 補 fallback
      if (!d.vless_tcp_dns) { d.vless_tcp_dns = d.vless_link; }
      if (!d.vless_xhttp_dns) { d.vless_xhttp_dns = d.vless_link; }
      if (!d.vless_tcp_ip) { d.vless_tcp_ip = d.vless_link; }
      if (!d.vless_xhttp_ip) { d.vless_xhttp_ip = d.vless_link; }
      // 跳到完成頁
      document.getElementById('step-form').style.display = 'none';
      document.getElementById('step-running').style.display = 'none';
      document.getElementById('step-done').style.display = 'block';
      document.getElementById('status-pill').textContent = '✓ 完成';
      document.getElementById('status-pill').style.color = 'var(--green)';
      renderLinks(d);
      // summary
      const sum = document.getElementById('summary');
      sum.innerHTML = `
        <table style="width:100%">
          <tr><td style="padding:6px;color:var(--text2)">N1 主機名</td><td>${d.n1_name}</td></tr>
          <tr><td style="padding:6px;color:var(--text2)">N1 內網 IP</td><td>${d.lan_ip}</td></tr>
          <tr><td style="padding:6px;color:var(--text2)">對外 port</td><td>${d.ext_port}</td></tr>
          <tr><td style="padding:6px;color:var(--text2)">DDNS</td><td>${d.ddns_domain}.duckdns.org</td></tr>
          <tr><td style="padding:6px;color:var(--text2)">Xray 版本</td><td>${d.xray_version}</td></tr>
          <tr><td style="padding:6px;color:var(--text2)">完成時間</td><td>${new Date(d.finished_at).toLocaleString('zh-Hant')}</td></tr>
        </table>`;
      // 加「重新設定」按鈕
      const reset = document.createElement('button');
      reset.className = 'btn btn-danger';
      reset.style.marginTop = '16px';
      reset.textContent = '🔄 重新設定（會洗掉 N1 設定）';
      reset.onclick = () => {
        if (confirm('確定要重新跑 wizard？這會把 N1 改回全新狀態。')) {
          localStorage.removeItem('n1-wizard-done');
          location.reload();
        }
      };
      sum.parentNode.appendChild(reset);
    }
  } catch (e) {}
})();

async function pollStatus(){
  const term = document.getElementById('terminal');
  const bar = document.getElementById('progress-bar');
  let lastLog = 0;

  while(true){
    const r = await fetch('/api/status');
    const s = await r.json();

    // log
    for(let i = lastLog; i < s.log.length; i++){
      const l = s.log[i];
      const cls = l.level === 'err' ? 'err' : l.level === 'warn' ? 'warn' : l.level === 'ok' ? 'ok' : '';
      term.innerHTML += `<div class="${cls}">[${l.time}] ${l.msg}</div>`;
      term.scrollTop = term.scrollHeight;
    }
    lastLog = s.log.length;

    if(s.step){
      renderSteps(s.step, s.status);
      const idx = STEPS.findIndex(x => x.id === s.step);
      bar.style.width = ((idx+1) / STEPS.length * 100) + '%';
    }

    if(s.status === 'done'){
      bar.style.width = '100%';
      renderSteps(null, 'done');
      document.getElementById('status-pill').textContent = '✓ 完成';
      document.getElementById('status-pill').style.color = 'var(--green)';
      document.getElementById('step-running').style.display = 'none';
      document.getElementById('step-done').style.display = 'block';
      // 直接用 wizard 回傳的 vless（已經從 xray config 算配對的）
      renderLinks(s.result);
      // 儲存完成狀態到 localStorage（刷新不會回到初始頁）
      try {
        localStorage.setItem('n1-wizard-done', JSON.stringify({
          vless_link: s.result.vless_link,
          vless_tcp_dns: s.result.vless_tcp_dns,
          vless_xhttp_dns: s.result.vless_xhttp_dns,
          vless_tcp_ip: s.result.vless_tcp_ip,
          vless_xhttp_ip: s.result.vless_xhttp_ip,
          transport: s.result.transport,
          public_ip: s.result.public_ip,
          n1_name: s.result.n1_name,
          lan_ip: s.result.lan_ip,
          ext_port: s.result.ext_port,
          ddns_domain: s.result.ddns_domain,
          xray_version: s.result.xray_version,
          finished_at: new Date().toISOString(),
        }));
      } catch (e) {}
      // 填 summary
      const sum = document.getElementById('summary');
      const r = s.result;
      sum.innerHTML = `
        <table style="width:100%">
          <tr><td style="padding:6px;color:var(--text2)">N1 主機名</td><td>${r.n1_name}</td></tr>
          <tr><td style="padding:6px;color:var(--text2)">N1 內網 IP</td><td>${r.lan_ip}</td></tr>
          <tr><td style="padding:6px;color:var(--text2)">對外 port（TCP/XHTTP）</td><td>${r.ext_port} / ${Number(r.ext_port)+1}</td></tr>
          <tr><td style="padding:6px;color:var(--text2)">DDNS</td><td>${r.ddns_domain}</td></tr>
          <tr><td style="padding:6px;color:var(--text2)">公網 IP</td><td>${r.public_ip}</td></tr>
          <tr><td style="padding:6px;color:var(--text2)">傳輸</td><td>🚀 TCP + ✈️ XHTTP（皆已啟用）</td></tr>
          <tr><td style="padding:6px;color:var(--text2)">Xray 版本</td><td>${r.xray_version}</td></tr>
        </table>`;
      break;
    }
    if(s.status === 'error'){
      document.getElementById('status-pill').textContent = '✕ 失敗';
      document.getElementById('status-pill').style.color = 'var(--red)';
      break;
    }
    await new Promise(r => setTimeout(r, 800));
  }
}
</script>
</body>
</html>
'''

def log(msg, level="info"):
    STATE["log_queue"].put({"time": time.strftime("%H:%M:%S"), "msg": msg, "level": level})

def run_cmd(cmd, timeout=60, check=True, env=None):
    """跑指令並即時 log"""
    log(f"$ {cmd[:200]}{'...' if len(cmd)>200 else ''}")
    if STATE.get("dry_run"):
        log(f"  [DRY-RUN] 假裝執行", "warn")
        return 0, "(dry-run output)"
    try:
        p = subprocess.Popen(
            cmd, shell=True, executable="/bin/bash",
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            env=env or os.environ.copy()
        )
        out, _ = p.communicate(timeout=timeout)
        text = out.decode("utf-8", errors="replace")
        for line in text.strip().split("\n"):
            if line.strip():
                log(f"  {line}")
        if check and p.returncode != 0:
            raise RuntimeError(f"指令失敗（exit {p.returncode}）: {cmd[:100]}")
        return p.returncode, text
    except subprocess.TimeoutExpired:
        p.kill()
        log(f"  ⚠ 指令 timeout ({timeout}s)", "warn")
        return -1, ""
    except Exception as e:
        log(f"  ✕ 錯誤: {e}", "err")
        if check:
            raise
        return -1, ""

def detect_upnp(timeout=4):
    """偵測路由器是否支援 UPnP (IGD)。有 miniupnpc 就用它，否則用 SSDP M-SEARCH 探測。
    回傳 True/False（best-effort）"""
    import socket as _socket
    # 方法一：若已裝 upnpc，直接跑（最可靠）
    try:
        if subprocess.run(["command", "-v", "upnpc"], capture_output=True).returncode == 0:
            o = subprocess.run(["timeout", "6", "upnpc", "-l"], capture_output=True, text=True, timeout=8)
            if "Found valid IGD" in o.stdout:
                return True
            if "No IGD" in o.stdout or "found : 0" in o.stdout:
                return False
    except Exception:
        pass
    # 方法二：SSDP M-SEARCH (不需額外套件)
    try:
        msg = ("M-SEARCH * HTTP/1.1\r\n"
               "HOST: 239.255.255.250:1900\r\n"
               "MAN: \"ssdp:discover\"\r\n"
               "MX: 2\r\n"
               "ST: urn:schemas-upnp-org:device:InternetGatewayDevice:1\r\n\r\n")
        s = _socket.socket(_socket.AF_INET, _socket.SOCK_DGRAM, _socket.IPPROTO_UDP)
        s.setsockopt(_socket.SOL_SOCKET, _socket.SO_REUSEADDR, 1)
        s.settimeout(timeout)
        s.sendto(msg.encode(), ("239.255.255.250", 1900))
        end = time.time() + timeout
        while time.time() < end:
            try:
                data, _ = s.recvfrom(2048)
                txt = data.decode("utf-8", "replace")
                if "InternetGatewayDevice" in txt or "IGD" in txt or "urn:schemas-upnp-org:service:WANIPConnection" in txt:
                    s.close()
                    return True
            except Exception:
                break
        s.close()
    except Exception:
        pass
    return False

def gen_xray_keys():
    """產生 Reality 的 x25519 公私鑰對 (用 xray x25519)，回傳 (priv, pub)"""
    if STATE.get("dry_run"):
        log("  [DRY-RUN] 假裝產生 x25519 金鑰", "warn")
        return "DRYRUN_PRIVATE_KEY_BASE64", "DRYRUN_PUBLIC_KEY_BASE64"
    out = subprocess.check_output(["xray", "x25519"], env={**os.environ, "LC_ALL": "C.UTF-8", "LANG": "C.UTF-8"})
    text = out.decode("utf-8", errors="replace")
    # xray 26.3.27+ 輸出格式：Password (PublicKey): <value>
    m = re.search(r"PrivateKey:\s*(\S+)", text)
    priv = m.group(1) if m else ""
    m = re.search(r"Password\s*\(PublicKey\):\s*(\S+)", text)
    if m:
        pub = m.group(1)
    else:
        # 舊版 xray: Password: <value>
        m = re.search(r"Password:\s*(\S+)", text)
        pub = m.group(1) if m else ""
    return priv, pub

def gen_uuid():
    if STATE.get("dry_run"):
        return "00000000-0000-0000-0000-000000000000"
    return subprocess.check_output(["cat", "/proc/sys/kernel/random/uuid"], env={**os.environ, "LC_ALL": "C.UTF-8", "LANG": "C.UTF-8"}).decode("utf-8").strip()

def gen_shortid():
    if STATE.get("dry_run"):
        return "0000000000000000"
    out = subprocess.check_output(["head", "-c", "8", "/dev/urandom"], env={**os.environ, "LC_ALL": "C.UTF-8", "LANG": "C.UTF-8"})
    return out.hex()

def step_sysinfo():
    log("查看系統版本")
    run_cmd("uname -a")
    run_cmd("cat /etc/os-release | head -5")
    run_cmd("ip -4 addr show eth0 | grep inet")
    run_cmd("ss -tlnp 2>&1 | grep -E ':22 ' || echo '  (ssh 還沒啟動？)'", check=False)

def step_hostname(name):
    log(f"設定 hostname 為 {name}")
    run_cmd(f"hostnamectl set-hostname {name}")
    run_cmd(f"hostname; cat /etc/hostname")

def step_duckdns(domain, token, ip):
    """註冊 DuckDNS 子網域"""
    log(f"註冊 DuckDNS {domain}.duckdns.org → {ip}")
    url = f"https://www.duckdns.org/update?domains={domain}&token={token}&ip={ip}"
    rc, text = run_cmd(f"curl -s --max-time 10 '{url}'", check=False, timeout=20)
    if "OK" in text:
        log(f"  ✓ DuckDNS 註冊成功 (回應: {text})", "ok")
    else:
        log(f"  ⚠ DuckDNS 註冊回應: {text}", "warn")
        log("  → 可能是 token 已滿 5 個子網域配額", "warn")
        log("  → 但 sub 步驟會繼續使用既有設定", "warn")

def step_bbr():
    log("啟用 BBR 加速")
    # 檢查是否已啟用
    rc, text = run_cmd("sysctl net.ipv4.tcp_congestion_control", check=False)
    if "bbr" in text:
        log("  ✓ BBR 已啟用", "ok")
        return
    # 寫設定
    run_cmd("""grep -q tcp_congestion_control /etc/sysctl.conf || cat >> /etc/sysctl.conf <<'EOF'

# BBR
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr
EOF""")
    # 只套用 BBR 那兩行（避免 sysctl.conf 裡其他不存在於 6.12 kernel 的設定失敗）
    run_cmd("sysctl -w net.core.default_qdisc=fq", check=False)
    run_cmd("sysctl -w net.ipv4.tcp_congestion_control=bbr", check=False)
    run_cmd("sysctl net.ipv4.tcp_congestion_control")

def step_install_xray(port, n1_name, domain, sni="dash.cloudflare.com", mode="tcp", path="/ray"):
    """同時安裝兩種模式入站：
       - 🚀 TCP  : 外部 port      （一般，相容性最高）
       - ✈️ XHTTP: 外部 port + 1  （穩定，跨境更穩）
       兩者共用同一組金鑰/UUID/shortId/SNI → 手機可同時存兩條 vless
       回傳 {"uuid","pub","sid","priv","path_tcp","path_xhttp","port_tcp","port_xhttp"}
    """
    log("安裝 Xray VPN")
    if not Path("/usr/local/bin/xray").exists():
        # 用 PC 端下載 + 傳過來方式 (繞過 N1 端 GitHub 限制)
        log("  從 N1 端 curl 安裝（如果失敗就會 fall back）")
        rc, _ = run_cmd("bash -c \"$(curl -fsSL https://github.com/XTLS/Xray-install/raw/main/install-release.sh)\" @ install --version v26.3.27", timeout=120, check=False)
        if rc != 0:
            log("  N1 端下載失敗，需先從 PC 傳 binary", "warn")
            raise RuntimeError("Xray 安裝失敗（網路問題，請從 PC 端手動跑 install-release.sh）")
    run_cmd("xray version | head -1")

    # 產生金鑰
    log("  產生 x25519 金鑰 + UUID + shortId")
    priv, pub = gen_xray_keys()
    uuid = gen_uuid()
    sid = gen_shortid()
    log(f"    UUID: {uuid}")
    log(f"    shortId: {sid}")

    port_tcp = int(port)
    port_xhttp = int(port) + 1

    def _inbound(port_n, network, flow, extra_stream, tag):
        ss = {
            "network": network,
            "security": "reality",
            "realitySettings": {
                "show": False,
                "dest": f"{sni}:443",
                "xver": 0,
                "serverNames": [sni],
                "privateKey": priv,
                "minClientVer": "",
                "shortIds": [sid]
            }
        }
        ss.update(extra_stream)
        return {
            "tag": tag,
            "listen": "0.0.0.0",
            "port": port_n,
            "protocol": "vless",
            "settings": {
                "clients": [{"id": uuid, "flow": flow, "level": 0}],
                "decryption": "none"
            },
            "streamSettings": ss
        }

    inbounds = [
        _inbound(port_tcp, "tcp", "xtls-rprx-vision", {}, "tcp-in"),
        _inbound(port_xhttp, "xhttp", "", {"xhttpSettings": {"mode": "auto", "path": path}}, "xhttp-in"),
    ]
    log(f"  🚀 TCP  入站 : {port_tcp}")
    log(f"  ✈️ XHTTP 入站 : {port_xhttp} (path={path})")

    # 寫 config
    config = {
        "log": {"loglevel": "warning"},
        "inbounds": inbounds,
        "outbounds": [
            {"protocol": "freedom", "tag": "direct"},
            {"protocol": "blackhole", "tag": "block"}
        ]
    }
    Path(XRAY_CONFIG).parent.mkdir(parents=True, exist_ok=True)
    Path(XRAY_CONFIG).write_text(json.dumps(config, indent=2))
    log(f"  ✓ 寫入 {XRAY_CONFIG}")

    # 啟動
    run_cmd("systemctl enable xray")
    run_cmd("systemctl restart xray")
    time.sleep(2)
    run_cmd("systemctl status xray --no-pager -l | head -5")
    run_cmd(f"ss -tlnp | grep -E ':{port_tcp}|:{port_xhttp}' || echo '  ! 埠沒監聽'")

    return {"uuid": uuid, "pub": pub, "sid": sid, "priv": priv,
            "path": path, "port_tcp": port_tcp, "port_xhttp": port_xhttp}

def step_vpn_test(port, uuid, pub, sid, sni="dash.cloudflare.com", mode="tcp", path="/ray"):
    log("VPN 通道測試（N1 本機 curl ifconfig.me）")
    if STATE.get("dry_run"):
        log("  [DRY-RUN] 假裝 VPN 通了，回傳假 IP", "warn")
        return "127.0.0.1"
    flow = "xtls-rprx-vision" if mode == "tcp" else ""
    stream = {"network": mode, "security": "reality", "realitySettings": {
        "serverName": sni, "fingerprint": "chrome",
        "publicKey": pub, "shortId": sid
    }}
    if mode == "xhttp":
        stream["xhttpSettings"] = {"mode": "auto", "path": path}
    cfg_client = {
        "log": {"loglevel": "warning"},
        "inbounds": [{"listen": "127.0.0.1", "port": 10999, "protocol": "socks", "settings": {"udp": True}}],
        "outbounds": [{
            "protocol": "vless",
            "settings": {"vnext": [{"address": "127.0.0.1", "port": int(port), "users": [{"id": uuid, "encryption": "none", "flow": flow}]}]},
            "streamSettings": stream
        }]
    }
    Path("/tmp/n1-test-client.json").write_text(json.dumps(cfg_client, indent=2))
    run_cmd("pkill -f 'xray run -c /tmp/n1-test-client' 2>/dev/null; sleep 1", check=False)
    run_cmd("xray run -c /tmp/n1-test-client.json > /tmp/n1-test.log 2>&1 &", check=False)
    # 等 xray 完全起來（listen 10999 才視為 ok）
    log("  等 xray client 起來...")
    for i in range(15):
        time.sleep(1)
        rc, text = run_cmd("ss -tlnp 2>/dev/null | grep -q ':10999' && echo OK || echo WAIT", check=False, timeout=5)
        if "OK" in text:
            log(f"  ✓ xray client 起來（{i+1}s）")
            break
    else:
        log("  ⚠ 15s 還沒起來，再等一下", "warn")
        time.sleep(3)
    rc, text = run_cmd("curl -s --max-time 10 --socks5-hostname 127.0.0.1:10999 https://ifconfig.me", check=False)
    run_cmd("pkill -f 'xray run -c /tmp/n1-test-client' 2>/dev/null", check=False)
    ip = text.strip()
    if ip and re.match(r"^\d+\.\d+\.\d+\.\d+$", ip):
        log(f"  ✓ VPN 通道通了，外部 IP = {ip}", "ok")
        return ip
    else:
        log(f"  ✕ VPN 測試失敗: {ip}", "err")
        raise RuntimeError("VPN 通道測試失敗，請檢查 xray 設定")

def step_install_ddns_go(domain, token, n1_name, ext_port):
    log("安裝 ddns-go")
    Path("/opt/ddns-go").mkdir(parents=True, exist_ok=True)
    if not Path("/usr/local/bin/ddns-go").exists():
        log("  嘗試從 N1 端 GitHub 下載")
        rc, _ = run_cmd("""
cd /tmp
ARCH=arm64
VER=6.17.7
URL="https://github.com/jeessy2/ddns-go/releases/download/v${VER}/ddns-go_${VER}_linux_${ARCH}.tar.gz"
curl -fsSL -o ddns-go.tar.gz "$URL" && tar -xzf ddns-go.tar.gz -C /opt/ddns-go && chmod +x /opt/ddns-go/ddns-go && cp /opt/ddns-go/ddns-go /usr/local/bin/ddns-go && echo OK
""", timeout=60, check=False)
        if rc != 0:
            raise RuntimeError("N1 端下載 ddns-go 失敗（需從 PC 端下載 scp 過來）")
    log("  寫 systemd service")
    run_cmd("""cat > /etc/systemd/system/ddns-go.service <<'EOF'
[Unit]
Description=ddns-go
After=network-online.target
Wants=network-online.target
[Service]
Type=simple
ExecStart=/usr/local/bin/ddns-go -l :9877 -c /etc/ddns-go/config.yaml
WorkingDirectory=/etc/ddns-go
Restart=always
RestartSec=10
LimitNOFILE=65536
[Install]
WantedBy=multi-user.target
EOF""")
    log(f"  寫 config ({domain}.duckdns.org)")
    Path("/etc/ddns-go").mkdir(parents=True, exist_ok=True)
    config = f"""dnsconf:
    - name: duckdns-{n1_name}
      ipv4:
        enable: true
        gettype: url
        url: https://api.ipify.org, https://4.ipw.cn, https://myip.ipip.net
        netinterface: eth0
        cmd: ""
        domains:
            - {domain}.duckdns.org
      ipv6:
        enable: false
        gettype: netInterface
        url: https://speed.neu6.edu.cn/getIP.php, https://v6.ident.me
        netinterface: ""
        cmd: ""
        ipv6reg: ""
        domains:
            - ""
      dns:
        name: callback
        id: "https://www.duckdns.org/update?domains={domain}&token={token}&ip=#{{ip}}"
        secret: ""
        extparam: ""
      ttl: ""
      httpinterface: ""
user:
    username: yourdomain
    password: $2a$10$S2MGSKusHped8UeLLDzWw.KyvPA0ExgKGUylj5JDF5JIWbMNwdLhe
webhook:
    webhookurl: ""
    webhookrequestbody: ""
    webhookheaders: ""
notallowwanaccess: true
lang: en
"""
    Path(CONFIG_PATH).write_text(config)
    run_cmd("chown root:root /etc/ddns-go/config.yaml && chmod 600 /etc/ddns-go/config.yaml")
    run_cmd("systemctl daemon-reload")
    run_cmd("systemctl enable ddns-go")
    run_cmd("systemctl restart ddns-go")
    time.sleep(5)
    rc, text = run_cmd("journalctl -u ddns-go --no-pager -n 5", check=False)
    if "OK" in text:
        log("  ✓ ddns-go callback 成功", "ok")
    else:
        log(f"  ⚠ ddns-go log: {text[:200]}", "warn")

def step_install_to_emmc():
    log("灌 Armbian 到 eMMC（讓 N1 開機不需 USB 碟）")
    log("  ⚠ 這步經常失敗（boot0 硬體保護），失敗了繼續走完流程即可", "warn")
    rc, _ = run_cmd("/usr/sbin/armbian-install -m yes < /dev/null", timeout=300, check=False)
    if rc == 0:
        log("  ✓ eMMC 灌好", "ok")
    else:
        log("  ⚠ armbian-install 失敗，可能是 boot0 硬體保護", "warn")
        log("  → 正常現象，N1 仍然可以從 USB 碟開機", "warn")

def step_router_port_forward(router_url, router_pwd, n1_ip, ext_port):
    """設定路由器 port forward：先自動試 UPnP（不需密碼），失敗才給手動指示"""
    log("設定路由器 port forward")
    log(f"  N1 內網 IP: {n1_ip}, 外部 port → 內部: {ext_port} → {ext_port}")

    # 方法一：UPnP 自動申請（不需密碼）
    if step_upnp_port_forward(n1_ip, ext_port):
        return True

    # 方法二：UPnP 失敗 → 改手動指示
    log("  ⚠ UPnP 未能自動開埠，改請用戶手動設定", "warn")
    log(f"  → 用瀏覽器開 {router_url} → 進階設定 → 埠轉發 → 新增：", "warn")
    log(f"  → 名稱：xray-{n1_ip.split('.')[-1]}", "warn")
    log(f"  → 協定：TCP  外部埠：{ext_port}  內部 IP：{n1_ip}  內部埠：{ext_port}", "warn")
    return False

def step_upnp_port_forward(n1_ip, ext_port):
    """用 UPnP 向路由器自動申請開埠（不需密碼）"""
    log("  嘗試 UPnP 自動開埠（不需密碼）...")
    # 確保有 upnpc
    rc, _ = run_cmd("command -v upnpc", check=False)
    if rc != 0:
        log("    安裝 miniupnpc...")
        run_cmd("apt-get update -qq 2>&1 | tail -1", check=False)
        rc2, _ = run_cmd("apt-get install -y -qq miniupnpc 2>&1 | tail -2", check=False)
        if rc2 != 0:
            log("    ✕ 無法安裝 miniupnpc", "err")
            return False
    # 用 upnpc 加 UDP+TCP 映射
    out = ""
    for proto in ("TCP", "UDP"):
        try:
            rc, out = run_cmd(
                f"timeout 15 upnpc -e n1-xray -a {n1_ip} {ext_port} {ext_port} {proto}",
                check=False)
            log(f"    [{proto}] {out.strip()[-80:]}")
        except Exception as e:
            log(f"    [{proto}] err {e}", "err")
    # 判斷是否成功映射（upnpc 成功輸出: "redirected to internal" 或 "InternalIP:Port"）
    ok = ("redirected to internal" in out) or ("InternalIP:Port" in out)
    if ok:
        log(f"  ✓ UPnP 自動開埠成功：外部 {ext_port} → {n1_ip}:{ext_port}")
    else:
        conflict = "718" in out or "ConflictInMapping" in out
        if conflict:
            log(f"  ⚠ 外部 {ext_port} 已被其它裝置占用（UPnP 衝突），可能已存在映射", "warn")
        else:
            log(f"  ⚠ UPnP 開埠未確認成功，回傳：{out.strip()[-120:]}", "warn")
    return ok
    # 不 raise — port forward 由用戶手動設定

def _build_vless(uuid, host, port, sni, pbk, sid, n1_name, mode="tcp", path="/ray"):
    """依傳輸模式組 vless 分享連結。host 可為 DDNS 網域或公網 IP。"""
    trans = ""
    if mode == "xhttp":
        trans = f"&type=xhttp&path={urllib.parse.quote(path)}&mode=auto"
    else:
        trans = "&type=tcp&flow=xtls-rprx-vision"
    return (f"vless://{uuid}@{host}:{port}"
            f"?encryption=none&security=reality&sni={sni}&fp=chrome"
            f"&pbk={pbk}&sid={sid}{trans}"
            f"#{urllib.parse.quote(n1_name)}-HK-Reality")

def run_install_thread(cfg):
    """背景跑完整安裝流程"""
    STATE["status"] = "running"
    STATE["log"] = []
    STATE["started_at"] = time.time()
    try:
        sni = cfg.get("sni", "dash.cloudflare.com").strip() or "dash.cloudflare.com"
        STATE["step"] = "sysinfo"
        step_sysinfo()

        # 抓 IP
        STATE["step"] = "hostname"
        step_hostname(cfg["n1_name"])

        # 抓外部 IP
        if STATE.get("dry_run"):
            wan_ip = "127.0.0.1"
            log(f"[DRY-RUN] 假裝外部 IP: {wan_ip}", "warn")
        else:
            rc, text = run_cmd("curl -s --max-time 5 https://api.ipify.org", check=False)
            wan_ip = text.strip() or "0.0.0.0"
        log(f"外部 IP: {wan_ip}")

        STATE["step"] = "duckdns"
        step_duckdns(cfg["duckdns_domain"], cfg["duckdns_token"], wan_ip)

        STATE["step"] = "bbr"
        step_bbr()

        STATE["step"] = "xray"
        # 兩種模式都會安裝（TCP + XHTTP）；mode 只決定「測試哪個」與「主連結」
        xray_mode = cfg.get("mode", "tcp")
        if xray_mode not in ("tcp", "xhttp"):
            xray_mode = "tcp"  # both/其它 → 主連結用 TCP
        xray_path = "/ray" + os.urandom(4).hex()
        keys = step_install_xray(cfg["ext_port"], cfg["n1_name"], cfg["duckdns_domain"], sni, xray_mode, xray_path)
        STATE["result_transport"] = {"mode": xray_mode, "path": xray_path}

        STATE["step"] = "vpn-test"
        # 測 TCP（主連結那條；XHTTP 結構相同，真機測過可用）
        ip = step_vpn_test(keys["port_tcp"], keys["uuid"], keys["pub"], keys["sid"], sni, "tcp", keys["path"])

        STATE["step"] = "ddns-go"
        step_install_ddns_go(cfg["duckdns_domain"], cfg["duckdns_token"], cfg["n1_name"], cfg["ext_port"])

        STATE["step"] = "emmс"
        step_install_to_emmc()

        STATE["step"] = "router-pf"
        # 抓 eth0 IP
        if STATE.get("dry_run"):
            n1_ip = "192.168.x.x"  # dry-run 用固定值
        else:
            rc, text = run_cmd("ip -4 addr show eth0 | grep -oP 'inet \\K[\\d.]+' | head -1", check=False)
            n1_ip = text.strip() or "192.168.31.x"
        step_router_port_forward(cfg["router_url"], cfg["router_pwd"], n1_ip, cfg["ext_port"])

        STATE["step"] = "final"
        # 從 N1 實際 xray config 抓 privkey（這是真正寫進 xray server 的 key）
        # 用 Python 算配對的 pubkey（保證 vless 連結的 pbk 跟 server privkey 配對）
        if STATE.get("dry_run"):
            pbk = keys['pub']
        else:
            try:
                import base64 as _b64
                # 從 xray config 抓 privkey（不是再跑 xray x25519！）
                rc2, xcfg_text = run_cmd(f"cat {XRAY_CONFIG}", timeout=5, check=False)
                import re as _re
                pm = _re.search(r'"privateKey":\s*"([^"]+)"', xcfg_text)
                pbk = keys['pub']
                if pm:
                    priv_from_config = pm.group(1)
                    priv_padded = priv_from_config + "=" * ((-len(priv_from_config)) % 4)
                    priv_bytes = _b64.urlsafe_b64decode(priv_padded)
                    if len(priv_bytes) == 32:
                        # 用 Python 算 pubkey（保證配對）
                        try:
                            from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey
                            actual_pub_bytes = X25519PrivateKey.from_private_bytes(priv_bytes).public_key().public_bytes_raw()
                            actual_pub_b64 = _b64.urlsafe_b64encode(actual_pub_bytes).decode().rstrip("=")
                            log(f"  ✓ 從 xray config 抓 privkey，用 Python 算配對 pubkey: {actual_pub_b64[:20]}...")
                            pbk = actual_pub_b64
                        except ImportError:
                            # 沒 cryptography 庫就回退用 wizard 的 pub
                            log("  ⚠ 沒 cryptography 庫，用 wizard 的 pubkey", "warn")
                            pbk = keys['pub']
                    else:
                        log(f"  ✕ privkey 長度錯 ({len(priv_bytes)} bytes)", "err")
                else:
                    log("  ✕ 找不到 privkey", "err")
                log(f"  ✓ vless 連結 pbk 從 server privkey 算（保證配對）")
            except Exception as e:
                log(f"  ✕ vless 組裝失敗: {e}", "err")
                pbk = keys['pub']

        # 同時產生「四條」vless：網域版 + 公網IP版 × (🚀TCP + ✈️XHTTP)
        dns_host = f"{cfg['duckdns_domain']}.duckdns.org"
        pub_host = wan_ip if wan_ip and wan_ip != "0.0.0.0" else dns_host
        vless_tcp_dns   = _build_vless(keys['uuid'], dns_host, keys['port_tcp'],   sni, pbk, keys['sid'], cfg['n1_name'], "tcp",   keys['path'])
        vless_xhttp_dns = _build_vless(keys['uuid'], dns_host, keys['port_xhttp'], sni, pbk, keys['sid'], cfg['n1_name'], "xhttp", keys['path'])
        vless_tcp_ip    = _build_vless(keys['uuid'], pub_host, keys['port_tcp'],   sni, pbk, keys['sid'], cfg['n1_name'], "tcp",   keys['path'])
        vless_xhttp_ip  = _build_vless(keys['uuid'], pub_host, keys['port_xhttp'], sni, pbk, keys['sid'], cfg['n1_name'], "xhttp", keys['path'])
        # 主連結（沿用舊欄位 = TCP 網域版，相容性最高）
        vless = vless_tcp_dns
        log("  ✓ 產生 4 條連結：網域版 / 公網IP版 × (TCP / XHTTP)")

        # xray 版本
        if STATE.get("dry_run"):
            xray_ver = "v26.3.27 (DRY-RUN)"
        else:
            rc, text = run_cmd("xray version | head -1", check=False)
            xray_ver = text.strip() or "v26.3.27"

        STATE["result"] = {
            "vless_link": vless,
            "vless_tcp_dns": vless_tcp_dns,
            "vless_xhttp_dns": vless_xhttp_dns,
            "vless_tcp_ip": vless_tcp_ip,
            "vless_xhttp_ip": vless_xhttp_ip,
            "n1_name": cfg["n1_name"],
            "lan_ip": n1_ip,
            "ext_port": cfg["ext_port"],
            "ddns_domain": dns_host,
            "public_ip": pub_host,
            "xray_version": xray_ver,
            "wan_ip": wan_ip,
            "transport": xray_mode,
            "path": xray_path if xray_mode == "xhttp" else "",
        }
        STATE["status"] = "done"
        log("🎉 全部完成！", "ok")
    except Exception as e:
        STATE["status"] = "error"
        log(f"✕ 失敗: {e}", "err")
        import traceback
        log(traceback.format_exc(), "err")
    finally:
        STATE["finished_at"] = time.time()

class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        # 抑制預設 log
        pass

    def do_GET(self):
        if self.path == "/" or self.path == "/index.html":
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(HTML_PAGE.encode("utf-8"))
        elif self.path == "/manual" or self.path == "/manual.html":
            try:
                with open("/root/manual.html", "rb") as f:
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html; charset=utf-8")
                    self.end_headers()
                    self.wfile.write(f.read())
            except FileNotFoundError:
                self.send_response(404)
                self.end_headers()
                self.wfile.write(b"Manual not found")
        elif self.path == "/api/status":
            # drain queue
            while not STATE["log_queue"].empty():
                STATE["log"].append(STATE["log_queue"].get())
            STATE["log"] = STATE["log"][-200:]  # 保留最後 200 條
            body = json.dumps({
                "status": STATE["status"],
                "step": STATE["step"],
                "log": STATE["log"],
                "result": STATE["result"],
            }).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(body)
        elif self.path == "/api/detect":
            # 自動偵測盒子環境，供前端預填
            import uuid as _uuid
            info = {"lan_ip": "", "gateway": "", "public_ip": "", "hostname": "", "suggested_name": "", "suggested_domain": ""}
            # LAN IP + 閘道
            try:
                o = subprocess.run(["ip", "-4", "addr", "show", "eth0"], capture_output=True, text=True, timeout=5)
                for line in o.stdout.splitlines():
                    if "inet " in line:
                        info["lan_ip"] = line.strip().split()[1].split("/")[0]
                        break
                o = subprocess.run(["ip", "route"], capture_output=True, text=True, timeout=5)
                for line in o.stdout.splitlines():
                    if "default via " in line:
                        info["gateway"] = line.split("default via ")[1].split()[0]
                        break
            except Exception:
                pass
            # hostname
            try:
                info["hostname"] = subprocess.run(["hostname"], capture_output=True, text=True, timeout=5).stdout.strip()
            except Exception:
                pass
            # 公網 IP（連網可能失敗，容錯）
            try:
                o = subprocess.run(["curl", "-sS", "-m", "5", "https://ifconfig.me"], capture_output=True, text=True, timeout=8)
                if o.returncode == 0 and o.stdout.strip():
                    info["public_ip"] = o.stdout.strip()
            except Exception:
                pass
            # 建議主機名 / 網域（隨機後綴，避免撞名）
            if info["hostname"]:
                base = info["hostname"]
            else:
                base = "n1"
            suff = _uuid.uuid4().hex[:4]
            info["suggested_name"] = f"{base}-{suff}"
            info["suggested_domain"] = f"{base}{suff.lower()}"
            # UPnP 偵測（供前端決定埠號是否自動/需手動）
            info["upnp"] = detect_upnp()
            body = json.dumps(info).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(body)
        elif self.path == "/api/update/info":
            self._json_resp(200, {"version": WIZARD_VERSION, "update_url": _get_update_url()})
        elif self.path == "/api/update/check":
            url = _get_update_url()
            if not url:
                self._json_resp(400, {"error": "尚未設定更新來源（請在系統管理填入 manifest 網址）"})
                return
            rc, out = run_cmd(f"curl -sSL -m 12 '{url}'", check=False)
            if rc != 0:
                self._json_resp(500, {"error": f"無法連上更新來源: {out.strip()[:100]}"})
                return
            try:
                out = out.lstrip("\ufeff") if isinstance(out, str) else out
                manifest = json.loads(out)
            except Exception as e:
                self._json_resp(500, {"error": f"manifest 不是有效 JSON: {str(e)[:80]}"})
                return
            remote = str(manifest.get("version", "")).strip()
            self._json_resp(200, {
                "current": WIZARD_VERSION,
                "remote": remote,
                "available": _version_tuple(remote) > _version_tuple(WIZARD_VERSION),
                "download_url": manifest.get("url", ""),
                "notes": manifest.get("notes", ""),
                "sha256": manifest.get("sha256", ""),
            })
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        if self.path == "/api/install":
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length).decode("utf-8")
            cfg = json.loads(body)
            if STATE["status"] == "running":
                self.send_response(409)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write('{"error":"已在執行中"}'.encode("utf-8"))
                return
            STATE["log"] = []
            STATE["result"] = None
            t = threading.Thread(target=run_install_thread, args=(cfg,), daemon=True)
            t.start()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b'{"ok":true}')
        elif self.path == "/api/reset_auth":
            # 接收 PC 端公鑰，安裝到 /root/.ssh/authorized_keys
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length).decode("utf-8")
            try:
                cfg = json.loads(body)
                pubkey = cfg.get("pubkey", "").strip()
                if not pubkey:
                    raise ValueError("empty pubkey")
                Path("/root/.ssh").mkdir(parents=True, exist_ok=True)
                with open("/root/.ssh/authorized_keys", "w") as f:
                    f.write(pubkey + "\n")
                subprocess.run(["chmod", "700", "/root/.ssh"], check=False)
                subprocess.run(["chmod", "600", "/root/.ssh/authorized_keys"], check=False)
                log(f"✓ /root/.ssh/authorized_keys 已更新")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(b'{"ok":true}')
            except Exception as e:
                self.send_response(500)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(f'{{"error":"{str(e)}"}}'.encode("utf-8"))
        elif self.path == "/api/admin/samba":
            # 改 Samba (nas) 密碼
            length = int(self.headers.get("Content-Length", 0))
            cfg = json.loads(self.rfile.read(length).decode("utf-8"))
            pwd = (cfg.get("password") or "").strip()
            if len(pwd) < 4:
                self._json_resp(400, {"error": "密碼至少 4 字元"})
                return
            rc, _ = run_cmd(f"printf '%s\\n%s\\n' '{pwd}' '{pwd}' | smbpasswd -s nas", check=False)
            if rc == 0:
                self._json_resp(200, {"ok": True, "msg": "Samba 密碼已更改"})
            else:
                self._json_resp(500, {"error": "smbpasswd 失敗"})
        elif self.path == "/api/admin/syncthing":
            # 改 Syncthing GUI 密碼
            length = int(self.headers.get("Content-Length", 0))
            cfg = json.loads(self.rfile.read(length).decode("utf-8"))
            pwd = (cfg.get("password") or "").strip()
            if len(pwd) < 4:
                self._json_resp(400, {"error": "密碼至少 4 字元"})
                return
            rc, hash_out = run_cmd(f"htpasswd -nbBC 10 admin '{pwd}' 2>/dev/null | cut -d: -f2", check=False)
            new_hash = hash_out.strip()
            if rc != 0 or not new_hash.startswith("$2"):
                self._json_resp(500, {"error": f"產生雜湊失敗: {hash_out[:80]}"})
                return
            CFG = "/var/lib/syncthing/config/config.xml"
            if not os.path.exists(CFG):
                self._json_resp(500, {"error": "找不到 Syncthing config"})
                return
            txt = Path(CFG).read_text()
            if "<password>" in txt:
                txt = re.sub(r"<password>.*?</password>", f"<password>{new_hash}</password>", txt, count=1, flags=re.S)
            else:
                txt = txt.replace("</address>", f"</address>\n        <user>admin</user>\n        <password>{new_hash}</password>", 1)
            Path(CFG).write_text(txt)
            subprocess.run(["chown", "-R", "syncthing", "/var/lib/syncthing/config"], check=False)
            subprocess.run(["systemctl", "restart", "syncthing"], check=False)
            self._json_resp(200, {"ok": True, "msg": "Syncthing GUI 密碼已更新（帳號固定 admin）"})
        elif self.path == "/api/admin/hostname":
            # 改 hostname（mDNS 跟著變）
            length = int(self.headers.get("Content-Length", 0))
            cfg = json.loads(self.rfile.read(length).decode("utf-8"))
            name = (cfg.get("hostname") or "").strip()
            if not re.match(r"^[a-zA-Z0-9-]{2,30}$", name):
                self._json_resp(400, {"error": "主機名只能英數與 -（2-30 字）"})
                return
            rc, _ = run_cmd(f"hostnamectl set-hostname '{name}'", check=False)
            Path("/etc/hostname").write_text(name + "\n")
            subprocess.run(["systemctl", "restart", "avahi-daemon"], check=False)
            if rc == 0:
                self._json_resp(200, {"ok": True, "msg": f"主機名已改為 {name}，mDNS 訪問: http://{name}.local:8080"})
            else:
                self._json_resp(500, {"error": "hostnamectl 失敗"})
        elif self.path == "/api/admin/update-url":
            length = int(self.headers.get("Content-Length", 0))
            cfg = json.loads(self.rfile.read(length).decode("utf-8"))
            url = (cfg.get("url") or "").strip()
            if url and not url.startswith("http"):
                self._json_resp(400, {"error": "網址需以 http/https 開頭"})
                return
            # 自動修正常見的錯誤網址（GitHub 網頁檢視 → raw 直連）
            if url:
                url = _fix_github_url(url)
            if url:
                Path(UPDATE_URL_FILE).write_text(url)
                self._json_resp(200, {"ok": True, "msg": "更新來源已儲存"})
            else:
                try: os.remove(UPDATE_URL_FILE)
                except Exception: pass
                self._json_resp(200, {"ok": True, "msg": "更新來源已清除"})
        elif self.path == "/api/update/apply":
            length = int(self.headers.get("Content-Length", 0))
            cfg = json.loads(self.rfile.read(length).decode("utf-8"))
            dl = (cfg.get("url") or "").strip()
            want_sha = (cfg.get("sha256") or "").strip().lower()
            if not dl.startswith("http"):
                self._json_resp(400, {"error": "缺少有效的下載網址"})
                return
            rc, out = run_cmd(f"curl -sSL -m 180 -o /tmp/n1update.tgz '{dl}'", check=False)
            if rc != 0 or not os.path.exists("/tmp/n1update.tgz") or os.path.getsize("/tmp/n1update.tgz") == 0:
                self._json_resp(500, {"error": f"下載失敗: {out.strip()[:100]}"})
                return
            if want_sha:
                rc, out = run_cmd("sha256sum /tmp/n1update.tgz", check=False)
                got = out.split()[0] if out else ""
                if got != want_sha:
                    self._json_resp(500, {"error": f"雜湊不符（{got[:16]}...），已中止"})
                    return
            run_cmd("rm -rf /tmp/n1update; mkdir -p /tmp/n1update; tar xzf /tmp/n1update.tgz -C /tmp/n1update", check=False)
            applied = []
            src = Path("/tmp/n1update/n1-setup-server.py")
            if src.exists():
                shutil.copy(src, "/root/n1-setup-server.py")
                os.chmod("/root/n1-setup-server.py", 0o755)
                applied.append("n1-setup-server.py")
            src = Path("/tmp/n1update/manual.html")
            if src.exists():
                shutil.copy(src, "/root/manual.html")
                applied.append("manual.html")
            if not applied:
                self._json_resp(500, {"error": "更新包內沒有可套用的檔案"})
                return
            def _do_restart():
                time.sleep(1.5)
                rc, _ = run_cmd("systemctl restart n1-setup-server", check=False)
                if rc != 0:
                    run_cmd("pkill -f n1-setup-server; sleep 1; cd /root; setsid python3 /root/n1-setup-server.py --port 8080 > /tmp/n1-wiz.log 2>&1 < /dev/null & disown", check=False)
            threading.Thread(target=_do_restart, daemon=True).start()
            self._json_resp(200, {"ok": True, "msg": f"已套用 {', '.join(applied)}，服務重啟中——請 30 秒後重新整理頁面"})
        else:
            self.send_response(404)
            self.end_headers()

    def _json_resp(self, code, obj):
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(obj).encode("utf-8"))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8080)
    ap.add_argument("--bind", default="0.0.0.0")
    ap.add_argument("--dry-run", action="store_true", help="假裝跑指令，不真的執行（測試用）")
    args = ap.parse_args()

    if args.dry_run:
        STATE["dry_run"] = True
        print("="*60)
        print("⚠️  DRY-RUN 模式 — 指令會被 mock，不真的執行")
        print("="*60)

    # 顯示啟動資訊
    print("="*60)
    print("N1 家用旁路由安裝精靈")
    print("="*60)
    print(f"  監聽: http://{args.bind}:{args.port}")
    rc, text = run_cmd("ip -4 addr show eth0 | grep -oP 'inet \\K[\\d.]+' | head -1", check=False)
    lan = text.strip() or "(無 eth0 IP)"
    print(f"  N1 內網 IP: {lan}")
    print(f"  用瀏覽器打開: http://{lan}:{args.port}/")
    print("="*60)
    print("  按 Ctrl+C 停止")
    print("="*60)

    class ThreadedHTTPServer(http.server.HTTPServer):
        """多線程 + daemon threads，不會卡住"""
        daemon_threads = True
        def process_request(self, request, client_address):
            t = threading.Thread(target=self.process_request_thread, args=(request, client_address), daemon=True)
            t.start()
        def process_request_thread(self, request, client_address):
            try:
                self.process_request_thread_inner(request, client_address)
            except Exception:
                self.handle_error(request, client_address)
        def process_request_thread_inner(self, request, client_address):
            # 模擬 BaseServer._process_request
            self.finish_request(request, client_address)
            self.shutdown_request(request)

    server = ThreadedHTTPServer((args.bind, args.port), Handler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n停止中...")

if __name__ == "__main__":
    main()
